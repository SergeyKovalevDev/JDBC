package ru.sf.jdbc.jdbctemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbctemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
