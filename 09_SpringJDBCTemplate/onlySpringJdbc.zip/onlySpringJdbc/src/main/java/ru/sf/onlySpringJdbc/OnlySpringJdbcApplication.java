package ru.sf.onlySpringJdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlySpringJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlySpringJdbcApplication.class, args);
	}

}
