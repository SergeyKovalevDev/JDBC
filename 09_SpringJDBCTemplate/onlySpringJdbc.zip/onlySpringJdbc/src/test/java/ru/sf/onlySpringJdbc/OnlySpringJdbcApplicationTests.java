package ru.sf.onlySpringJdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlySpringJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
